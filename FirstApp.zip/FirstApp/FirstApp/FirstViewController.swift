//
//  ViewController.swift
//  FirstApp
//
//  Created by Alexander Zub on 29.07.2022.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var changeNameButton: UIButton!
    @IBOutlet weak var colorSegControl: UISegmentedControl!
    @IBOutlet weak var mySwitch: UISwitch!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        changeNameButton.layer.cornerRadius = 8
        
    }

    @IBAction func changeButtonTap(_ sender: Any) {
        guard let name = nameTextField.text, let lastName = lastNameTextField.text else {
            return
        }
        let string = name + " " + lastName
        
        nameLable.text = string
    }
    
    @IBAction func tapNext(_ sender: UIButton) {
        performSegue(withIdentifier: "FirstToSecond", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segue.identifier {
        case "FirstToSecond":
           
            let destVC = segue.destination as! SecondViewController
            
            if let name = self.nameLable.text {
                destVC.name = name
    
                switch colorSegControl.selectedSegmentIndex {
                case 0: destVC.view.backgroundColor = .red
                case 1: destVC.view.backgroundColor = .green
                case 2: destVC.view.backgroundColor = .yellow
                default: break
                }
            destVC.view.backgroundColor
            }
        default: break
        }
    }
    
    @IBAction func switchToggle(_ sender: UISwitch) {
        changeNameButton.isEnabled = mySwitch.isOn
    }
}

