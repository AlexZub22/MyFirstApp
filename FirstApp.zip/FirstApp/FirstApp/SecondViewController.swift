//
//  SecondViewController.swift
//  FirstApp
//
//  Created by Alexander Zub on 29.07.2022.
//

import UIKit

class SecondViewController: UIViewController {

    var name = ""
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.name = self.label.text
        
    }
    
    
}
