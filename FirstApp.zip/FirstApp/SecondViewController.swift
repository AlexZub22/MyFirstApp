//
//  SecondViewController.swift
//  FirstApp
//
//  Created by Alexander Zub on 31.07.2022.
//

import UIKit

class SecondViewController: UIViewController {

    var name = ""
    @IBOutlet var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.label.text = self.name
    }
    
   
    @IBAction func backTap(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
   
